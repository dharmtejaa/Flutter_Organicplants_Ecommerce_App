import 'package:flutter/material.dart';
import 'package:organicplants/authentication/loginscreen.dart';
import 'package:organicplants/widgets/customButtons/custombutton.dart';
import 'package:organicplants/widgets/custom_widgets/custom_textfield.dart';
import 'package:organicplants/screens/home_screen.dart';

enum Gender {
  male('Male'),
  female('Female'),
  others('Other');

  final String label;
  const Gender(this.label);
}

class Basicdetails extends StatefulWidget {
  const Basicdetails({super.key});

  @override
  State<Basicdetails> createState() => _BasicdetailsState();
}

class _BasicdetailsState extends State<Basicdetails> {
  final TextEditingController userName = TextEditingController();
  final TextEditingController email = TextEditingController();
  final TextEditingController dob = TextEditingController();
  final ValueNotifier<Gender?> selectedGender = ValueNotifier<Gender?>(null);

  @override
  void dispose() {
    userName.dispose();
    email.dispose();
    dob.dispose();
    selectedGender.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        leading: Padding(
          padding: const EdgeInsets.only(left: 10.0),
          child: IconButton(
            onPressed: () {
              Navigator.push(
                context,
                MaterialPageRoute(builder: (context) => Loginscreen()),
              );
            },
            icon: const Icon(Icons.arrow_back_ios),
          ),
        ),
      ),
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.symmetric(horizontal: 20),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              SizedBox(height: MediaQuery.of(context).size.height * 0.03),
              RichText(
                text: TextSpan(
                  text: "Basic ",
                  style: TextStyle(
                    fontSize: 35,
                    // ignore: deprecated_member_use
                    color: Colors.black.withOpacity(0.8),
                    fontWeight: FontWeight.w500,
                  ),
                  children: [
                    TextSpan(
                      text: "Details",
                      style: TextStyle(
                        fontSize: 35,
                        color: Colors.green.shade400,
                        fontWeight: FontWeight.w500,
                      ),
                    ),
                  ],
                ),
              ),
              SizedBox(height: MediaQuery.of(context).size.height * 0.04),
              CustomTextField(
                hintText: "Name",
                controller: userName,
                keyboardType: TextInputType.name,
                prefixIcon: Icons.person,
              ),
              SizedBox(height: MediaQuery.of(context).size.height * 0.01),
              CustomTextField(
                hintText: "Email",
                controller: email,
                prefixIcon: Icons.email_outlined,
                keyboardType: TextInputType.emailAddress,
              ),
              SizedBox(height: MediaQuery.of(context).size.height * 0.01),
              CustomTextField(
                hintText: "DD/MM/YYYY",
                controller: dob, // ✅ Fixed controller
                keyboardType: TextInputType.datetime,
                prefixIcon: Icons.calendar_month,
              ),
              SizedBox(height: MediaQuery.of(context).size.height * 0.02),
              const Text(
                "Select Gender",
                style: TextStyle(fontSize: 16, fontWeight: FontWeight.w500),
              ),
              ValueListenableBuilder<Gender?>(
                valueListenable: selectedGender,
                builder: (context, value, _) {
                  return Row(
                    mainAxisAlignment:
                        MainAxisAlignment
                            .spaceEvenly, // Adjust spacing between items
                    children:
                        Gender.values.map((gender) {
                          return Row(
                            children: [
                              Radio<Gender>(
                                value: gender,
                                groupValue: value,
                                onChanged: (val) => selectedGender.value = val,
                                activeColor: Colors.green.shade400,
                              ),
                              Text(
                                gender.label,
                                style: TextStyle(fontSize: 17),
                              ),
                            ],
                          );
                        }).toList(),
                  );
                },
              ),

              SizedBox(height: MediaQuery.of(context).size.height * 0.34),
              CustomButton(
                ontap: () {
                  // You can add validation or navigation here
                  Navigator.pushReplacement(
                    context,
                    MaterialPageRoute(builder: (context) => HomeScreen()),
                  );
                },
                backgroundColor: Colors.green.shade400,
                text: 'Continue',
                textColor: Colors.white,
              ),
              SizedBox(height: MediaQuery.of(context).size.height * 0.01),
              Center(
                child: RichText(
                  textAlign: TextAlign.center,
                  text: TextSpan(
                    text: "By continuing, you agree to Organic Plants ",
                    style: TextStyle(
                      fontSize: 11,
                      // ignore: deprecated_member_use
                      color: Colors.black.withOpacity(0.8),
                    ),
                    children: [
                      TextSpan(
                        text: "Terms of Service ",
                        style: TextStyle(
                          fontSize: 11,
                          color: Colors.green.shade400,
                        ),
                      ),
                      TextSpan(
                        text: "and ",
                        style: TextStyle(
                          fontSize: 11,
                          // ignore: deprecated_member_use
                          color: Colors.black.withOpacity(0.8),
                        ),
                      ),
                      TextSpan(
                        text: "Privacy Policy",
                        style: TextStyle(
                          fontSize: 11,
                          color: Colors.green.shade400,
                        ),
                      ),
                    ],
                  ),
                ),
              ),
              SizedBox(height: MediaQuery.of(context).size.height * 0.01),
            ],
          ),
        ),
      ),
    );
  }
}
