import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:organicplants/authentication/otpscreen.dart';
import 'package:organicplants/widgets/customButtons/custombutton.dart';
import 'package:organicplants/widgets/custom_widgets/custom_textfield.dart';
import 'package:organicplants/screens/home_screen.dart';

class Loginscreen extends StatefulWidget {
  const Loginscreen({super.key});

  @override
  State<Loginscreen> createState() => _LoginscreenState();
}

class _LoginscreenState extends State<Loginscreen> {
  final TextEditingController number = TextEditingController();

  final formKey = GlobalKey<FormState>();

  final auth = FirebaseAuth.instance;

  final countryCode = "+91";

  @override
  Widget build(BuildContext context) {
    void login() {
      if (formKey.currentState!.validate()) {
        auth.verifyPhoneNumber(
          phoneNumber: "+91${number.text}",
          verificationCompleted: (_) {
            ScaffoldMessenger.of(context).showSnackBar(
              const SnackBar(
                content: Text("Verification Completed!"),
                backgroundColor: Colors.green,
                duration: Duration(seconds: 2),
              ),
            );
          },
          verificationFailed: (e) {
            ScaffoldMessenger.of(context).showSnackBar(
              SnackBar(
                content: Text(e.message.toString()),
                backgroundColor: Colors.red[400],
                duration: const Duration(seconds: 2),
              ),
            );
          },
          codeSent: (String verificationId, int? resendToken) {
            ScaffoldMessenger.of(context).showSnackBar(
              SnackBar(
                content: const Text("OTP sent Successfully! 🎉"),
                backgroundColor: Colors.green[400],
                duration: const Duration(seconds: 2),
              ),
            );

            Navigator.push(
              context,
              MaterialPageRoute(
                builder:
                    (context) => OTPscreen(
                      verificationId: verificationId,
                      text: number.text,
                    ),
              ),
            );
          },
          codeAutoRetrievalTimeout: (e) {
            ScaffoldMessenger.of(context).showSnackBar(
              const SnackBar(
                content: Text("Code Auto Retrieval Timeout!"),
                backgroundColor: Colors.red,
                duration: Duration(seconds: 2),
              ),
            );
          },
        );
      } else {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text("Please enter a valid phone number ❌"),
            backgroundColor: Colors.grey,
            duration: Duration(seconds: 2),
          ),
        );
      }
    }

    // ignore: deprecated_member_use
    return WillPopScope(
      onWillPop: () async {
        return await showDialog(
          context: context,
          builder:
              (context) => AlertDialog(
                title: const Text("Are you sure?"),
                content: const Text("Do you want to exit the app?"),
                actions: [
                  TextButton(
                    onPressed: () => Navigator.of(context).pop(false),
                    child: const Text("No"),
                  ),
                  TextButton(
                    onPressed: () => Navigator.of(context).pop(true),
                    child: const Text("Yes"),
                  ),
                ],
              ),
        );
      },
      child: Scaffold(
        resizeToAvoidBottomInset: true,
        appBar: AppBar(
          actions: [
            GestureDetector(
              onTap:
                  () => Navigator.push(
                    context,
                    MaterialPageRoute(builder: (context) => HomeScreen()),
                  ),
              child: Text(
                "Skip",
                style: TextStyle(fontSize: 20, color: Colors.green.shade400),
              ),
            ),
            SizedBox(width: MediaQuery.of(context).size.width * 0.05),
          ],
        ),
        body: SafeArea(
          child: SingleChildScrollView(
            padding: const EdgeInsets.symmetric(horizontal: 21),
            child: Form(
              key: formKey,
              child: Column(
                mainAxisAlignment: MainAxisAlignment.start,
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: [
                      Expanded(
                        flex: 2,
                        child: Align(
                          alignment: Alignment.topLeft,
                          child: RichText(
                            text: TextSpan(
                              text: "Login \n",
                              style: TextStyle(
                                fontSize: 35,
                                color: Colors.green.shade400,
                                fontWeight: FontWeight.w500,
                              ),
                              children: [
                                TextSpan(
                                  text: "to get Started",
                                  style: TextStyle(
                                    fontSize: 35,
                                    fontWeight: FontWeight.w500,
                                    // ignore: deprecated_member_use
                                    color: Colors.black.withOpacity(0.7),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                      ),
                      Expanded(
                        child: Image.asset(
                          'assets/ltree.png',
                          width: 200,
                          height: MediaQuery.of(context).size.height * 0.2,
                        ),
                      ),
                    ],
                  ),

                  CustomTextField(
                    hintText: 'Number',
                    controller: number,
                    keyboardType: TextInputType.number,
                    prefixIcon: Icons.phone,
                  ),
                  SizedBox(height: MediaQuery.of(context).size.height * 0.01),
                  Align(
                    alignment: Alignment.topLeft,
                    child: Text(
                      " You'll recieve an OTP on the number above.",
                      style: TextStyle(fontSize: 15, color: Colors.black54),
                    ),
                  ),
                  SizedBox(height: MediaQuery.of(context).size.height * 0.45),
                  CustomButton(
                    ontap: login,
                    backgroundColor: Colors.green.shade400,
                    text: 'Continue',
                    textColor: Colors.white,
                  ),
                  SizedBox(
                    height: MediaQuery.of(context).size.height * 0.02,
                  ), // for scroll spacing
                  RichText(
                    textAlign: TextAlign.center,
                    text: TextSpan(
                      text: "By continuing, you agree to Orgnaic Plants ",
                      style: TextStyle(
                        fontSize: 11,
                        // ignore: deprecated_member_use
                        color: Colors.black.withOpacity(0.8),
                      ),
                      children: [
                        TextSpan(
                          text: "Terms of Service ",
                          style: TextStyle(
                            fontSize: 11,
                            color: Colors.green.shade400,
                          ),
                        ),
                        TextSpan(
                          text: "and ",
                          style: TextStyle(
                            fontSize: 11,
                            // ignore: deprecated_member_use
                            color: Colors.black.withOpacity(0.8),
                          ),
                        ),
                        TextSpan(
                          text: "Privacy Policy ",
                          style: TextStyle(
                            fontSize: 11,
                            color: Colors.green.shade400,
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}
