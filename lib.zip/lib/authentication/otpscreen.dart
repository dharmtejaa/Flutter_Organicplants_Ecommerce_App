import 'dart:async';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';
import 'package:organicplants/authentication/basicdetails.dart';
import 'package:organicplants/authentication/loginscreen.dart';
import 'package:organicplants/widgets/customButtons/custombutton.dart';
import 'package:pinput/pinput.dart';

class OTPscreen extends StatefulWidget {
  final String? text;
  final String? verificationId;
  const OTPscreen({super.key, this.text, this.verificationId});

  @override
  // ignore: library_private_types_in_public_api
  _OTPscreenState createState() => _OTPscreenState();
}

class _OTPscreenState extends State<OTPscreen> {
  ValueNotifier<int> timerValue = ValueNotifier(30);
  Timer? _timer;
  bool _isResendEnabled = false;

  final controller = TextEditingController();
  final focusNode = FocusNode();
  final formKey = GlobalKey<FormState>();
  final auth = FirebaseAuth.instance;

  @override
  void initState() {
    super.initState();
    startTimer();
  }

  @override
  void dispose() {
    controller.dispose();
    focusNode.dispose();
    _timer?.cancel();
    timerValue.dispose();
    super.dispose();
  }

  void startTimer() {
    timerValue.value = 30;
    _isResendEnabled = false;
    _timer?.cancel();
    _timer = Timer.periodic(const Duration(seconds: 1), (timer) {
      if (timerValue.value == 0) {
        _isResendEnabled = true;
        _timer?.cancel();
      } else {
        timerValue.value--;
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    Color borderColor = Colors.green.shade400;

    final defaultPinTheme = PinTheme(
      width: 60,
      height: 60,
      textStyle: TextStyle(fontSize: 22, color: Colors.green[400]),
      decoration: BoxDecoration(),
    );
    final cursor = Column(
      mainAxisAlignment: MainAxisAlignment.end,
      children: [
        Container(
          width: 60,
          height: 3,
          decoration: BoxDecoration(
            color: borderColor,
            borderRadius: BorderRadius.circular(8),
          ),
        ),
      ],
    );
    final preFilledWidget = Column(
      mainAxisAlignment: MainAxisAlignment.end,
      children: [
        Container(
          width: 60,
          height: 3,
          decoration: BoxDecoration(
            color: Colors.grey,
            borderRadius: BorderRadius.circular(8),
          ),
        ),
      ],
    );

    return Scaffold(
      appBar: AppBar(
        actions: [
          GestureDetector(
            onTap:
                () => Navigator.pushReplacement(
                  context,
                  MaterialPageRoute(builder: (context) => Loginscreen()),
                ),
            child: Text(
              "Skip",
              style: TextStyle(fontSize: 20, color: Colors.green.shade400),
            ),
          ),
          SizedBox(width: MediaQuery.of(context).size.width * 0.05),
        ],
        leading: Padding(
          padding: const EdgeInsets.only(left: 10.0),
          child: IconButton(
            onPressed: () {
              Navigator.push(
                context,
                MaterialPageRoute(builder: (context) => Loginscreen()),
              );
            },
            icon: const Icon(Icons.arrow_back_ios),
          ),
        ),
      ),
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.symmetric(horizontal: 20),
          child: Column(
            children: [
              SizedBox(height: MediaQuery.of(context).size.height * 0.03),
              Align(
                alignment: Alignment.topLeft,
                child: RichText(
                  text: TextSpan(
                    text: "OTP ",
                    style: TextStyle(
                      fontSize: 35,
                      color: Colors.green.shade400,
                      fontWeight: FontWeight.w500,
                    ),
                    children: [
                      TextSpan(
                        text: "Verification",
                        style: TextStyle(
                          fontSize: 35,
                          // ignore: deprecated_member_use
                          color: Colors.black.withOpacity(0.7),
                          fontWeight: FontWeight.w500,
                        ),
                      ),
                    ],
                  ),
                ),
              ),
              SizedBox(height: MediaQuery.of(context).size.height * 0.01),
              Align(
                alignment: Alignment.topLeft,
                child: RichText(
                  text: TextSpan(
                    text:
                        "Please enter the verification code we've sent you on\n+91-${widget.text} ",
                    style: TextStyle(
                      fontSize: 15,
                      // ignore: deprecated_member_use
                      color: Colors.black.withOpacity(0.7),
                      fontWeight: FontWeight.w500,
                    ),
                    children: [
                      TextSpan(
                        recognizer:
                            TapGestureRecognizer()
                              ..onTap = () {
                                Navigator.push(
                                  context,
                                  MaterialPageRoute(
                                    builder: (context) => Loginscreen(),
                                  ),
                                );
                              },
                        text: "Edit",
                        style: TextStyle(
                          fontSize: 15,
                          color: Colors.green.shade400,
                          fontWeight: FontWeight.w500,
                        ),
                      ),
                    ],
                  ),
                ),
              ),
              Form(
                key: formKey,
                child: Container(
                  margin: EdgeInsets.symmetric(horizontal: 30, vertical: 50),
                  child: Pinput(
                    length: 6,
                    keyboardType: TextInputType.number,
                    controller: controller,
                    autofocus: true,
                    enabled: true,

                    pinAnimationType: PinAnimationType.slide,
                    focusNode: focusNode,
                    defaultPinTheme: defaultPinTheme,
                    showCursor: true,
                    cursor: cursor,
                    submittedPinTheme: defaultPinTheme.copyWith(
                      decoration: BoxDecoration(
                        border: Border(
                          bottom: BorderSide(
                            color: Colors.green.shade400,
                            width: 3,
                          ),
                        ),
                      ),
                    ),
                    preFilledWidget: preFilledWidget,
                    hapticFeedbackType: HapticFeedbackType.mediumImpact,
                  ),
                ),
              ),
              Align(
                alignment: Alignment.topRight,
                child: ValueListenableBuilder<int>(
                  valueListenable: timerValue,
                  builder: (context, value, child) {
                    return GestureDetector(
                      onTap:
                          _isResendEnabled
                              ? () {
                                startTimer();
                                ScaffoldMessenger.of(context).showSnackBar(
                                  SnackBar(content: Text("OTP resent")),
                                );
                              }
                              : null,
                      child: Text(
                        _isResendEnabled
                            ? "Resend Code"
                            : "Resend Code in $value s",
                        style: TextStyle(
                          color:
                              _isResendEnabled
                                  ? Colors.green.shade400
                                  : Colors.grey,
                          fontWeight: FontWeight.w500,
                        ),
                      ),
                    );
                  },
                ),
              ),
              SizedBox(height: MediaQuery.of(context).size.height * 0.43),
              CustomButton(
                ontap: () async {
                  if (controller.text.length == 6) {
                    final credential = PhoneAuthProvider.credential(
                      verificationId: widget.verificationId!,
                      smsCode: controller.text.trim(),
                    );

                    try {
                      await auth.signInWithCredential(credential);
                      // ignore: use_build_context_synchronously
                      ScaffoldMessenger.of(context).showSnackBar(
                        SnackBar(
                          content: const Text("OTP Verified Successfully! 🎉"),
                          backgroundColor: Colors.green[400],
                          duration: const Duration(seconds: 2),
                        ),
                      );
                      Future.delayed(const Duration(seconds: 2), () {
                        Navigator.pushReplacement(
                          // ignore: use_build_context_synchronously
                          context,
                          MaterialPageRoute(
                            builder: (context) => Basicdetails(),
                          ),
                        );
                      });
                    } catch (e) {
                      // ignore: use_build_context_synchronously
                      ScaffoldMessenger.of(context).showSnackBar(
                        SnackBar(content: Text("OTP Verification failed: $e")),
                      );
                    }
                  } else {
                    ScaffoldMessenger.of(context).showSnackBar(
                      SnackBar(
                        content: Text("Please enter a valid 6-digit OTP"),
                      ),
                    );
                  }
                },
                backgroundColor: Colors.green.shade400,
                text: 'Verify Code',
                textColor: Colors.white,
              ),
              SizedBox(
                height: MediaQuery.of(context).size.height * 0.02,
              ), // for scroll spacing
              RichText(
                textAlign: TextAlign.center,
                text: TextSpan(
                  text: "By continuing, you agree to Organic Plants ",
                  style: TextStyle(
                    fontSize: 11,
                    // ignore: deprecated_member_use
                    color: Colors.black.withOpacity(0.8),
                  ),
                  children: [
                    TextSpan(
                      text: "Terms of Service ",
                      style: TextStyle(
                        fontSize: 11,
                        color: Colors.green.shade400,
                      ),
                    ),
                    TextSpan(
                      text: "and ",
                      style: TextStyle(
                        fontSize: 11,
                        // ignore: deprecated_member_use
                        color: Colors.black.withOpacity(0.8),
                      ),
                    ),
                    TextSpan(
                      text: "Privacy Policy ",
                      style: TextStyle(
                        fontSize: 11,
                        color: Colors.green.shade400,
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
