import 'package:flutter/material.dart';
import 'package:organicplants/providers/bottom_nav_provider.dart';
import 'package:organicplants/providers/onboarding_provider.dart';
import 'package:organicplants/screens/splashscreen.dart';
import 'package:provider/provider.dart';
import 'package:firebase_core/firebase_core.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp(
    options: const FirebaseOptions(
      apiKey: "AIzaSyBfbYeG53nOm2E0amp-XNe2SSuCdkiI8v8",
      appId: "1:662081729826:android:6db49ff6e6f8abaf37e17b",
      messagingSenderId: "662081729826",
      projectId: "organicplants143",
      storageBucket: "organicplants143.firebasestorage.app",
    ),
  );
  runApp(
    MultiProvider(
      providers: [
        ChangeNotifierProvider(create: (_) => OnboardingProvider()),
        ChangeNotifierProvider(create: (_) => BottomNavProvider()),
      ],
      child: const MyApp(),
    ),
  );
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        scaffoldBackgroundColor:
            Colors.white, //const Color.fromARGB(255, 235, 240, 235),
        splashColor: Colors.transparent,
        highlightColor: Colors.transparent,
        hoverColor: Colors.transparent,
        appBarTheme: AppBarTheme(
          backgroundColor: Colors.white,
          foregroundColor: Colors.black,
          elevation: 0,
        ),
        // colorScheme: ColorScheme.fromSeed(
        //   seedColor: Colors.white,
        //   brightness: Brightness.light,
        // ).copyWith(
        //   primary: Colors.white,
        //   secondary: Colors.white,
        //   surface: Colors.white,
        //   onPrimary: Colors.white, // text/icon color on green
        //   onSecondary: Colors.black, // text/icon color on white
        // ),
      ),

      home: Splashscreen(),
    );
  }
}
