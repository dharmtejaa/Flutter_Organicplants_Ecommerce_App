import 'package:flutter/material.dart';
import 'package:organicplants/services/all_plants_global_data.dart';
import 'package:organicplants/widgets/custom_widgets/auto_banner_with_notifier.dart';
import 'package:organicplants/widgets/custom_widgets/plant_section_widget.dart';
import 'package:organicplants/widgets/custom_widgets/plantcategory.dart';
import 'package:organicplants/widgets/custom_widgets/search_by_category.dart';

class HomeTab extends StatefulWidget {
  const HomeTab({super.key});

  @override
  State<HomeTab> createState() => _HomeTabState();
}

class _HomeTabState extends State<HomeTab> {
  @override
  void initState() {
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        automaticallyImplyLeading: false,

        title: Text(
          'Organic Plants',
          style: TextStyle(
            fontSize: 30,
            fontWeight: FontWeight.bold,
            color: Colors.green.shade400,
          ),
        ),
        actions: [
          IconButton(
            icon: const Icon(Icons.search),
            color: Colors.green.shade400,

            iconSize: 30,
            onPressed: () {
              // Implement search functionality
            },
          ),
          IconButton(
            icon: const Icon(Icons.favorite_border),
            color: Colors.green.shade400,
            iconSize: 30,
            onPressed: () {
              // Implement notifications functionality
            },
          ),
        ],
      ),

      body: SingleChildScrollView(
        child: SafeArea(
          child: Column(
            children: [
              AutoBannerWithNotifier(),
              const SizedBox(height: 20),
              SearchByCategory(),
              PlantSectionWidget(
                title: "Air Purifying",
                onSeeAll: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder:
                          (context) => PlantCategory(
                            plant: airPurifyingPlants,
                            category: "Air Purifying Plants",
                          ),
                    ),
                  );
                },
                plants: airPurifyingPlants,
              ),
              PlantSectionWidget(
                title: "Low Maintenance",
                onSeeAll: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder:
                          (context) => PlantCategory(
                            plant: lowMaintenancePlants,
                            category: "Low Maintenance Plants",
                          ),
                    ),
                  );
                },
                plants: lowMaintenancePlants,
              ),
              PlantSectionWidget(
                title: "Pet Friendly",
                onSeeAll: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder:
                          (context) => PlantCategory(
                            plant: petFriendlyPlants,
                            category: "Pet Friendly Plants",
                          ),
                    ),
                  );
                },
                plants: petFriendlyPlants,
              ),
              PlantSectionWidget(
                title: "Sun Loving",
                onSeeAll: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder:
                          (context) => PlantCategory(
                            plant: petFriendlyPlants,
                            category: "Sun Loving Plants",
                          ),
                    ),
                  );
                },
                plants: sunLovingPlants,
              ),
            ],
          ),
        ),
      ),
    );
  }
}
