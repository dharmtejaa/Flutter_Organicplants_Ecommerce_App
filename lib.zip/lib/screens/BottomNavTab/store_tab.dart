import 'package:flutter/material.dart';
import 'package:organicplants/services/all_plants_global_data.dart';
import 'package:organicplants/widgets/custom_widgets/plantcategory.dart';

class StoreTab extends StatefulWidget {
  const StoreTab({super.key});

  @override
  State<StoreTab> createState() => _StoreTabState();
}

class _StoreTabState extends State<StoreTab> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        leading: IconButton(
          icon: Icon(Icons.arrow_back),
          onPressed: () {
            Navigator.pop(context);
          },
          color: Colors.green.shade400,
        ),
        title: Text(
          "Organic Plants Store",
          style: TextStyle(
            color: Colors.green.shade400,
            fontSize: 24,
            fontWeight: FontWeight.bold,
          ),
        ),
        centerTitle: true,
        actions: [
          IconButton(
            icon: const Icon(Icons.search),
            color: Colors.green.shade400,

            iconSize: 30,
            onPressed: () {
              // Implement search functionality
            },
          ),
          IconButton(
            icon: const Icon(Icons.favorite_border),
            color: Colors.green.shade400,
            iconSize: 30,
            onPressed: () {
              // Implement notifications functionality
            },
          ),
        ],
      ),
      body: SafeArea(
        child: Padding(
          padding: EdgeInsets.symmetric(horizontal: 16, vertical: 10),
          child: Column(
            children: [
              Expanded(
                child: GridView.builder(
                  itemCount: categories.length,
                  gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                    crossAxisCount: 2,

                    childAspectRatio: 1, // Adjusted for better aspect ratio
                  ),

                  itemBuilder: (context, index) {
                    return Padding(
                      padding: const EdgeInsets.symmetric(
                        horizontal: 5,
                        vertical: 5,
                      ), //
                      child: GestureDetector(
                        onTap: () {
                          // Navigate to PlantCategory with the selected category
                          Navigator.push(
                            context,
                            MaterialPageRoute(
                              builder:
                                  (context) => PlantCategory(
                                    plant: getPlantsByCategory(
                                      categories[index]['filterTag']!
                                          .toLowerCase()
                                          .trim(),
                                    ),
                                    category: categories[index]['title']!,
                                  ),
                            ),
                          );
                        },
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                          children: [
                            Container(
                              decoration: BoxDecoration(
                                shape: BoxShape.circle,
                                color: const Color.fromARGB(255, 237, 247, 237),
                              ),
                              padding: const EdgeInsets.all(5),
                              child: ClipOval(
                                child: Image.asset(
                                  categories[index]['imagePath']!,
                                  width: 150,
                                  height: 150,
                                  fit: BoxFit.cover,
                                ),
                              ),
                            ),
                            const SizedBox(height: 5),
                            Expanded(
                              child: Text(
                                categories[index]['title']!,
                                //textAlign: TextAlign.center,
                                style: TextStyle(
                                  fontSize: 20,
                                  color: Colors.green.shade400,
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                    );
                  },
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
