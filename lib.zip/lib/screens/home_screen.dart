import 'package:flutter/material.dart';
import 'package:organicplants/screens/BottomNavTab/cart_tab.dart';
import 'package:organicplants/screens/BottomNavTab/community_tab.dart';
import 'package:organicplants/screens/BottomNavTab/home_tab.dart';
import 'package:organicplants/screens/BottomNavTab/profile_tab.dart';
import 'package:organicplants/screens/BottomNavTab/store_tab.dart';
import 'package:provider/provider.dart';
import '../providers/bottom_nav_provider.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  static const List<Widget> _screens = [
    HomeTab(),
    StoreTab(),
    CommunityTab(),
    ProfileTab(),
    CartTab(),
  ];

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  @override
  Widget build(BuildContext context) {
    final currentIndex = context.select<BottomNavProvider, int>(
      (p) => p.currentIndex,
    );

    return Scaffold(
      body: IndexedStack(index: currentIndex, children: HomeScreen._screens),

      /// Only BottomNavigationBar listens for changes
      bottomNavigationBar: Consumer<BottomNavProvider>(
        builder:
            (context, provider, _) => BottomNavigationBar(
              type: BottomNavigationBarType.fixed,
              currentIndex: provider.currentIndex,
              onTap: provider.updateIndex,
              selectedItemColor: Colors.green,
              unselectedItemColor: Colors.grey,
              backgroundColor: Colors.white,

              items: const [
                BottomNavigationBarItem(icon: Icon(Icons.home), label: "Home"),
                BottomNavigationBarItem(
                  icon: Icon(Icons.storefront),
                  label: "Store",
                ),
                BottomNavigationBarItem(
                  icon: Icon(Icons.groups),
                  label: "Community",
                ),
                BottomNavigationBarItem(
                  icon: Icon(Icons.account_circle_outlined),
                  label: "Profile",
                ),
                BottomNavigationBarItem(
                  icon: Icon(Icons.shopping_cart),
                  label: "Cart",
                ),
              ],
            ),
      ),
    );
  }
}
