import 'package:flutter/material.dart';

class OnAddTOCart extends StatefulWidget {
  const OnAddTOCart({super.key});

  @override
  State<OnAddTOCart> createState() => _OnAddTOCartState();
}

class _OnAddTOCartState extends State<OnAddTOCart> {
  @override
  Widget build(BuildContext context) {
    return Scaffold();
  }
}
