import 'package:flutter/material.dart';
import 'package:lottie/lottie.dart';
import 'package:organicplants/services/all_plants_global_data.dart';
import 'package:organicplants/authentication/loginscreen.dart';
import 'package:organicplants/providers/onboarding_provider.dart';
import 'package:provider/provider.dart';
import 'package:smooth_page_indicator/smooth_page_indicator.dart';

class OnboardingScreen extends StatefulWidget {
  const OnboardingScreen({super.key});

  @override
  State<OnboardingScreen> createState() => _OnboardingScreenState();
}

class _OnboardingScreenState extends State<OnboardingScreen> {
  final PageController _controller = PageController();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Stack(
          children: [
            Positioned.fill(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Consumer<OnboardingProvider>(
                    builder: (context, provider, child) {
                      final currentPage = provider.currentPage;
                      return Align(
                        alignment: Alignment.topRight,
                        child:
                            currentPage < onboardingData.length - 1
                                ? GestureDetector(
                                  onTap:
                                      () => provider.skipToEnd(
                                        _controller,
                                        onboardingData.length,
                                      ),
                                  child: Padding(
                                    padding: const EdgeInsets.only(right: 20),
                                    child: Text(
                                      'Skip',
                                      style: TextStyle(
                                        fontSize: 20,
                                        color: Colors.green.shade400,
                                        fontWeight: FontWeight.w500,
                                      ),
                                    ),
                                  ),
                                )
                                : const SizedBox(
                                  width: 39,
                                ), // Maintain spacing when 'Skip' is gone
                      );
                    },
                  ),

                  Expanded(
                    child: PageView.builder(
                      onPageChanged: (index) {
                        Provider.of<OnboardingProvider>(
                          context,
                          listen: false,
                        ).updatePage(index);
                      },
                      controller: _controller,
                      itemCount: onboardingData.length,
                      itemBuilder: (context, index) {
                        return Column(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            SizedBox(
                              height: MediaQuery.of(context).size.height * 0.3,
                              width: MediaQuery.of(context).size.width * 1,
                              child: Lottie.asset(
                                onboardingData[index]['image']!,
                                repeat: true,
                                fit: BoxFit.contain,
                              ),
                            ),

                            Text(
                              onboardingData[index]['title']!,
                              textAlign: TextAlign.center,
                              style: const TextStyle(
                                fontSize: 24,
                                fontFamily: 'Poppins',
                                fontWeight: FontWeight.bold,
                                color: Colors.green,
                              ),
                            ),

                            SizedBox(
                              height: MediaQuery.of(context).size.height * 0.02,
                            ),

                            Padding(
                              padding: const EdgeInsets.symmetric(
                                horizontal: 20,
                              ),
                              child: Text(
                                onboardingData[index]['description']!,
                                textAlign: TextAlign.center,
                                style: const TextStyle(
                                  fontSize: 16,
                                  fontFamily: 'Poppins',
                                  color: Colors.black54,
                                ),
                              ),
                            ),
                          ],
                        );
                      },
                    ),
                  ),
                  Consumer<OnboardingProvider>(
                    builder: (context, provider, child) {
                      final currentPage = provider.currentPage;
                      return Padding(
                        padding: const EdgeInsets.symmetric(
                          horizontal: 20,
                          vertical: 20,
                        ),
                        child: Row(
                          children: [
                            // Left part: Skip or SizedBox to maintain space

                            // Center part: Dots
                            SmoothPageIndicator(
                              controller: _controller,
                              count: onboardingData.length,
                              effect: ExpandingDotsEffect(
                                activeDotColor: Colors.green.shade400,
                                dotHeight: 10,
                                dotWidth: 10,
                                spacing: 10,
                              ),
                            ),
                            // Right part: Next/Login button
                            Expanded(
                              child: Align(
                                alignment: Alignment.centerRight,
                                child: ElevatedButton(
                                  onPressed: () {
                                    if (currentPage <
                                        onboardingData.length - 1) {
                                      provider.nextPage(
                                        _controller,
                                        onboardingData.length,
                                      );
                                    } else {
                                      Navigator.pushReplacement(
                                        context,
                                        MaterialPageRoute(
                                          builder: (context) => Loginscreen(),
                                        ),
                                      );
                                    }
                                  },
                                  style: ElevatedButton.styleFrom(
                                    backgroundColor: Colors.green.shade400,
                                    shape: StadiumBorder(),
                                  ),
                                  child: Text(
                                    currentPage == onboardingData.length - 1
                                        ? 'Login'
                                        : 'Next  ',
                                    style: TextStyle(
                                      color: Colors.white,
                                      fontSize: 20,
                                    ),
                                  ),
                                ),
                              ),
                            ),
                          ],
                        ),
                      );
                    },
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
