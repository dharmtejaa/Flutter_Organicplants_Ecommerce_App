import 'dart:async';

import 'package:flutter/material.dart';
import 'package:lottie/lottie.dart';
import 'package:organicplants/services/all_plants_global_data.dart';
import 'package:organicplants/screens/home_screen.dart';
import 'package:organicplants/services/plantservices.dart';

class Splashscreen extends StatefulWidget {
  const Splashscreen({super.key});

  @override
  State<Splashscreen> createState() => _SplashscreenState();
}

class _SplashscreenState extends State<Splashscreen> {
  @override
  void initState() {
    super.initState();
    _initializeData();
  }

  Future<void> _initializeData() async {
    try {
      allPlantsGlobal = await Plantservices.loadAllPlantsApi();
      indoorPlants = getPlantsByCategory('Indoor plant');
      outdoorPlants = getPlantsByCategory('Outdoor plant');
      medicinalPlants = getPlantsByCategory('Medicinal plant');
      herbsPlants = getPlantsByCategory('Herbs plant');
      floweringPlants = getPlantsByCategory('Flowering plant');
      bonsaiPlants = getPlantsByCategory('Bonsai plant');
      succulentsCactiPlants = getPlantsByCategory('Succulents & Cacti Plants');
      petFriendlyPlants = getPlantsByTag('Pet_Friendly');
      lowMaintenancePlants = getPlantsByTag('Low_Maintenance');
      airPurifyingPlants = getPlantsByTag('Air_Purifying');
      sunLovingPlants = getPlantsByTag('Sun_Loving');
      // Simulate a delay for loading data
      // This is where you can add any additional initialization logic
      await Future.delayed(Duration(seconds: 2));
      //allPlantsGlobal.shuffle();
      if (mounted) {
        Navigator.pushReplacement(
          context,
          MaterialPageRoute(builder: (_) => HomeScreen()),
        );
      }
      // ignore: empty_catches
    } catch (e) {}
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.end,
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            SizedBox(
              height: MediaQuery.of(context).size.height * 0.7,
              width: MediaQuery.of(context).size.width * 0.7,
              child: Lottie.asset(
                'assets/splash screen/earth_animation.json',
                repeat: false,
              ),
            ),
            Text(
              'O R G A N I C\nP L A N T S',
              textAlign: TextAlign.center,
              style: TextStyle(
                fontSize: 30,
                fontFamily: 'Poppins',
                fontWeight: FontWeight.bold,
                color: Colors.green.shade400,
              ),
            ),
            SizedBox(height: MediaQuery.of(context).size.height * 0.07),
          ],
        ),
      ),
    );
  }
}
