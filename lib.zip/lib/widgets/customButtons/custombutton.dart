import 'package:flutter/material.dart';

class CustomButton extends StatelessWidget {
  final String? text;
  final String? imagePath;
  final String? networkImage;
  final VoidCallback? ontap;
  final Color backgroundColor;
  final Color? textColor;

  const CustomButton({
    super.key,
    this.text,
    this.imagePath,
    this.networkImage,
    this.ontap,
    required this.backgroundColor,
    this.textColor,
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: ontap,
      child: Container(
        width: MediaQuery.of(context).size.width * 0.88,
        height: MediaQuery.of(context).size.height * 0.06,
        padding: const EdgeInsets.all(6),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(15),
          color: backgroundColor,
          boxShadow: [
            BoxShadow(
              color: const Color.fromARGB(255, 189, 184, 184),
              blurRadius: 3,
              offset: Offset(0, 1),
            ),
          ],
        ),
        alignment: Alignment.center,
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            if (text != null)
              Padding(
                padding: EdgeInsets.all(8.0),
                child: Text(
                  text!,
                  style: TextStyle(
                    fontSize: 20,
                    fontWeight: FontWeight.bold,
                    color: textColor,
                  ),
                ),
              ),
          ],
        ),
      ),
    );
  }
}
