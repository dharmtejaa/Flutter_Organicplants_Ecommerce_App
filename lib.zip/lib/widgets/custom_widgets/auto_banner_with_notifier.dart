import 'package:carousel_slider/carousel_slider.dart';
import 'package:flutter/material.dart';
import 'package:organicplants/services/all_plants_global_data.dart';
import 'package:organicplants/widgets/custom_widgets/plantcategory.dart';

import 'package:smooth_page_indicator/smooth_page_indicator.dart';

class AutoBannerWithNotifier extends StatefulWidget {
  const AutoBannerWithNotifier({super.key});

  @override
  State<AutoBannerWithNotifier> createState() => _AutoBannerWithNotifierState();
}

class _AutoBannerWithNotifierState extends State<AutoBannerWithNotifier> {
  final ValueNotifier<int> _currentIndex = ValueNotifier<int>(0);
  final CarouselSliderController _carouselController =
      CarouselSliderController();

  @override
  // ignore: override_on_non_overriding_member
  void dispose() {
    _currentIndex.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Stack(
      alignment: Alignment.bottomCenter,
      children: [
        CarouselSlider.builder(
          carouselController: _carouselController,
          itemCount: banners.length,
          options: CarouselOptions(
            height: 210,
            autoPlay: true,
            autoPlayInterval: const Duration(seconds: 5),
            autoPlayAnimationDuration: const Duration(seconds: 1),
            autoPlayCurve: Curves.easeInOut,
            enlargeCenterPage: true,
            viewportFraction: 0.8,
            enableInfiniteScroll: true,
            onPageChanged: (index, reason) {
              _currentIndex.value = index;
            },
          ),
          itemBuilder: (context, index, realIndex) {
            final banner = banners[index];
            return GestureDetector(
              onTap: () {
                // Navigate to the appropriate category based on the banner's filter tag
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder:
                        (_) => PlantCategory(
                          plant: getPlantsByTag(
                            banner['filterTag']!.toLowerCase(),
                          ),
                          category: banner['title'] ?? 'Unknown',
                        ),
                  ),
                );
              },
              child: ClipRRect(
                borderRadius: BorderRadius.circular(20),
                child: Stack(
                  fit: StackFit.expand,
                  children: [
                    Image.asset(banner['imagePath']!, fit: BoxFit.fill),
                    Container(
                      decoration: BoxDecoration(
                        gradient: LinearGradient(
                          colors: [
                            // ignore: deprecated_member_use
                            Colors.black.withOpacity(0.3),
                            Colors.transparent,
                          ],
                          begin: Alignment.bottomCenter,
                          end: Alignment.topCenter,
                        ),
                      ),
                    ),
                    Positioned(
                      left: 16,
                      bottom: 30,
                      right: 16,
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            banner['title']!,
                            style: const TextStyle(
                              color: Colors.white,
                              fontStyle: FontStyle.italic,
                              fontSize: 18,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                          const SizedBox(height: 3),
                          Text(
                            banner['subtitle']!,
                            style: const TextStyle(
                              color: Colors.white,
                              fontSize: 18,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            );
          },
        ),
        Positioned(
          bottom: 9,
          child: ValueListenableBuilder<int>(
            valueListenable: _currentIndex,
            builder:
                (context, value, _) => AnimatedSmoothIndicator(
                  duration: Duration(milliseconds: 300),
                  activeIndex: _currentIndex.value,
                  count: banners.length,
                  effect: ExpandingDotsEffect(
                    dotHeight: 8,
                    dotWidth: 8,
                    expansionFactor: 4,
                    // ignore: deprecated_member_use
                    dotColor: Colors.white.withOpacity(0.5),
                    // ignore: deprecated_member_use
                    activeDotColor: Colors.white.withOpacity(0.9),
                    spacing: 14,
                  ),
                  onDotClicked: (index) {
                    _carouselController.animateToPage(index);
                  },
                ),
          ),
        ),
      ],
    );
  }
}
