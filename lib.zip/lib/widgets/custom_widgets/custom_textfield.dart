import 'package:flutter/material.dart';

class CustomTextField extends StatefulWidget {
  final String hintText;
  final TextInputType? keyboardType;
  final bool obsecureText;
  final IconData? prefixIcon;
  final IconData? suffixIcon;
  final TextEditingController controller;
  final TextEditingController?
  confirmPasswordController; // ✅ For confirm password validation

  const CustomTextField({
    super.key,
    required this.hintText,
    this.keyboardType,
    this.obsecureText = false,
    this.prefixIcon,
    this.suffixIcon,
    required this.controller,
    this.confirmPasswordController, // ✅ Pass password controller to match confirm password
  });

  @override
  State<CustomTextField> createState() => _CustomTextFieldState();
}

class _CustomTextFieldState extends State<CustomTextField> {
  late bool _isObscure;
  late TextEditingController _controller;

  @override
  void initState() {
    super.initState();
    _controller = widget.controller;
    _isObscure = widget.obsecureText;
  }

  String? _validateInput(String? value) {
    if (value == null || value.isEmpty) {
      return 'Field cannot be empty!';
    }

    final hint = widget.hintText.toLowerCase();

    if (hint == "email") {
      if (!RegExp(
        r"^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$",
      ).hasMatch(value)) {
        return 'Enter a valid email!';
      }
    } else if (hint == "password" ||
        hint == "new password" ||
        hint == "confirm password") {
      if (value.length < 8) return 'Password must be at least 8 characters!';
      if (!RegExp(r'(?=.*[A-Z])').hasMatch(value)) {
        return 'Password must contain at least one uppercase letter!';
      }
      if (!RegExp(r'(?=.*[0-9])').hasMatch(value)) {
        return 'Password must contain at least one number!';
      }
      if (!RegExp(r'(?=.*[!@#$%^&*])').hasMatch(value)) {
        return 'Password must contain at least one special character!';
      }
    } else if (hint == "number") {
      if (!RegExp(r"^\d{10,}$").hasMatch(value)) {
        return 'Enter a valid phone number!';
      }
    } else if (hint == "name") {
      if (value.length < 3) return 'Name must be at least 3 characters!';
      if (!RegExp(r"^[a-zA-Z\s]+$").hasMatch(value)) {
        return 'Name must contain only letters!';
      }
    }

    return null;
  }

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: MediaQuery.of(context).size.width * 0.89,
      child: TextFormField(
        controller: _controller,
        obscureText: _isObscure,
        cursorErrorColor: Colors.green.shade400,
        cursorColor: Colors.green.shade400,
        maxLength: widget.hintText.toLowerCase().contains('number') ? 10 : 30,

        keyboardType: widget.keyboardType,
        validator: _validateInput, // ✅ Validation inside CustomTextField
        //autovalidateMode: AutovalidateMode.onUserInteraction,
        decoration: InputDecoration(
          counterText: '',
          suffixIconColor: Colors.green.shade400,
          prefixIconColor: Colors.green.shade400,

          hintText: widget.hintText,

          contentPadding: const EdgeInsets.all(20),
          prefixIcon:
              widget.prefixIcon != null ? Icon(widget.prefixIcon) : null,
          suffixIcon:
              widget.obsecureText
                  ? GestureDetector(
                    onTap: () {
                      setState(() {
                        _isObscure = !_isObscure;
                      });
                    },
                    child: Icon(
                      _isObscure ? Icons.visibility : Icons.visibility_off,
                    ),
                  )
                  : null,
          filled: true,
          fillColor: Colors.white,
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(15),
            borderSide: BorderSide(color: Colors.green.shade400),
          ),
          enabledBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(15),
            borderSide: BorderSide(color: Colors.green.shade400),
          ),
          focusedBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(15),
            borderSide: BorderSide(color: Colors.green.shade400),
          ),
          errorBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(15),
            borderSide: BorderSide(color: Colors.green.shade400),
          ),
          disabledBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(15),
            borderSide: BorderSide(color: Colors.green.shade400),
          ),
          focusedErrorBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(15),
            borderSide: BorderSide(color: Colors.green.shade400),
          ),
        ),
      ),
    );
  }
}
