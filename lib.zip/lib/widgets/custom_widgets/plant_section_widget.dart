import 'package:flutter/material.dart';
import 'package:organicplants/models/AllPlantsModel.dart';
import 'package:organicplants/widgets/custom_widgets/productcard.dart';

class PlantSectionWidget extends StatelessWidget {
  final String title;
  final VoidCallback onSeeAll;
  final List<AllPlantsModel> plants;
  const PlantSectionWidget({
    super.key,
    required this.title,
    required this.onSeeAll,
    required this.plants,
  });

  @override
  Widget build(BuildContext context) {
    plants.shuffle();
    if (plants.isEmpty) return const SizedBox(); // Skip empty sections
    return Column(
      children: [
        // Section Title with See All Button
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(
                title,
                style: TextStyle(
                  fontSize: 20,
                  fontWeight: FontWeight.bold,
                  color: Colors.green.shade400,
                ),
              ),
              TextButton(
                onPressed: onSeeAll,
                child: Text(
                  'See All',
                  style: TextStyle(color: Colors.green.shade400, fontSize: 16),
                ),
              ),
            ],
          ),
        ),
        // Horizontal ListView of Product Cards
        SizedBox(
          height: 285, // Adjust height as needed
          child: ListView.builder(
            itemCount: plants.length,
            scrollDirection: Axis.horizontal,
            padding: const EdgeInsets.symmetric(horizontal: 5),//
            itemBuilder: (context, index) {
              final plant = plants[index];
              return Padding(
                padding: EdgeInsets.only(
                  right: 12, // horizontal space between cards
                  bottom: 10, // optional for shadow space
                ),
                child: ProductCard(plant: plant),
              );
            },
          ),
        ),
      ],
    );
  }
}
