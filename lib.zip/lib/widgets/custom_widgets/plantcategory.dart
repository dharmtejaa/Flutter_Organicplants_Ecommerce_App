import 'package:flutter/material.dart';
import 'package:organicplants/models/AllPlantsModel.dart';
import 'package:organicplants/widgets/custom_widgets/productcard.dart';

class PlantCategory extends StatelessWidget {
  final List<AllPlantsModel> plant;
  final String category;
  const PlantCategory({super.key, required this.plant, required this.category});

  @override
  Widget build(BuildContext context) {
    final List<String> mainCategories = [
      'Indoor Plants',
      'Outdoor Plants',
      'Herbs Plants',
      'Succulents Plants',
      'Flowering Plants',
      'Bonsai Plants',
      'Medicinal Plants',
    ];
    final bool isMainCategory = mainCategories.contains(category);
    return Scaffold(
      appBar: AppBar(
        leading: IconButton(
          icon: Icon(Icons.arrow_back),
          onPressed: () {
            Navigator.pop(context);
          },
          color: Colors.green.shade400,
        ),
        title: Text(
          category,
          style: TextStyle(
            color: Colors.green.shade400,
            fontSize: 20,
            fontWeight: FontWeight.bold,
          ),
        ),
        centerTitle: true,
        actions: [
          IconButton(
            icon: Icon(Icons.search),
            onPressed: () {
              // Implement search functionality here
            },
            color: Colors.green.shade400,
          ),

          IconButton(
            icon: Icon(Icons.favorite_border_outlined),
            onPressed: () {
              // Implement search functionality here
            },
            color: Colors.green.shade400,
          ),
        ],
      ),
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const SizedBox(height: 10),
              Expanded(
                child: GridView.builder(
                  itemCount: plant.length,
                  gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                    crossAxisCount: 2,
                    crossAxisSpacing: 10,
                    mainAxisSpacing: 10,
                    childAspectRatio: 0.7, // Adjusted for better aspect ratio
                  ),

                  itemBuilder: (context, index) {
                    return isMainCategory
                        ? ProductCard(plant: plant[index], scifiname: true)
                        : ProductCard(plant: plant[index]);
                  },
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
