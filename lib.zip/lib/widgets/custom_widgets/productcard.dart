import 'package:flutter/material.dart';
import 'package:organicplants/models/AllPlantsModel.dart';
//import 'package:organicplants/services/plantservices.dart';

class ProductCard extends StatelessWidget {
  final AllPlantsModel plant;
  final bool? scifiname;
  const ProductCard({super.key, required this.plant, this.scifiname});
  // Removed invalid field initializer for 'plants'
  static const double cardWidth = 200;
  static const double cardHeight = 253;
  static const double imageHeight = 165;
  static const double imageWidth = 210;

  @override
  Widget build(BuildContext context) {
    final offerPrice = plant.prices?.offerPrice ?? 0;
    final originalPrice = plant.prices?.originalPrice ?? 0;
    final discountPercent =
        originalPrice > 0
            ? ((originalPrice - offerPrice) / originalPrice) * 100
            : 0;
    final discount = discountPercent.toStringAsFixed(0);

    return GestureDetector(
      onTap: () {},
      child: Container(
        height: cardHeight,
        width: cardWidth,
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(16),
          boxShadow: [
            BoxShadow(
              // ignore: deprecated_member_use
              color: Colors.grey.withOpacity(0.2),
              spreadRadius: 1,
              blurRadius: 5,
              offset: const Offset(0, 5), // bottom shadow only
            ),
          ],
        ),
        padding: const EdgeInsets.all(2),
        margin: const EdgeInsets.symmetric(horizontal: 1, vertical: 0),
        child: Column(
          children: [
            // Plant Image with Discount Badge & Favorite Icon
            Stack(
              children: [
                ClipRRect(
                  borderRadius: BorderRadius.all(Radius.circular(8)),
                  child: Image.network(
                    plant.images?[0].url ?? '',
                    height: imageHeight,
                    width: imageWidth,
                    fit: BoxFit.cover,
                  ),
                ),
                if (discountPercent > 0)
                  Positioned(
                    left: 3,
                    top: 10,
                    child: Container(
                      padding: const EdgeInsets.symmetric(
                        horizontal: 8,
                        vertical: 4,
                      ),
                      decoration: BoxDecoration(
                        color: Colors.red,
                        borderRadius: BorderRadius.circular(6),
                      ),
                      child: Text(
                        '$discount% OFF',
                        style: const TextStyle(
                          color: Colors.white,
                          fontWeight: FontWeight.bold,
                          fontSize: 12,
                        ),
                      ),
                    ),
                  ),
                Positioned(
                  top: 8,
                  right: 8,
                  child: Container(
                    decoration: BoxDecoration(
                      color: Colors.white,
                      shape: BoxShape.circle,
                      boxShadow: [
                        BoxShadow(
                          // ignore: deprecated_member_use
                          color: Colors.grey.withOpacity(0.2),
                          spreadRadius: 1,
                          blurRadius: 5,
                          offset: const Offset(
                            0,
                            2,
                          ), // shadow for favorite icon
                        ),
                      ],
                    ),
                    child: Icon(
                      Icons.favorite_border,
                      color: Colors.green.shade400,
                      size: 28,
                    ),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 4),
            // Plant Name
            Text(
              plant.commonName ?? 'Unknown Plant',
              style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 20),
            ),
            const SizedBox(height: 4),
            // Category
            Text(
              scifiname == true ? plant.scientificName ?? 'Unknown Scientific Name' : plant.category ?? 'Unknown Category Name',
              style: const TextStyle(
                fontWeight: FontWeight.bold,
                fontSize: 15,
                color: Colors.grey,
              ),
            ),
            const SizedBox(height: 4),
            // Rating
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                ...List.generate(5, (index) {
                  return Icon(
                    index < plant.rating!.floor()
                        ? Icons.star
                        : Icons.star_border,
                    color: Colors.amber,
                    size: 15,
                  );
                }),
                const SizedBox(width: 4),
                Text(
                  plant.rating!.toStringAsFixed(1),
                  style: const TextStyle(fontSize: 14, color: Colors.grey),
                ),
              ],
            ),
            const SizedBox(height: 4),
            // Pricing
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Text(
                  '₹${originalPrice.toStringAsFixed(2)}',
                  style: const TextStyle(
                    fontSize: 15,
                    decoration: TextDecoration.lineThrough,
                    color: Colors.grey,
                  ),
                ),
                const SizedBox(width: 8),
                Text(
                  '₹${offerPrice.toStringAsFixed(2)}',
                  style: TextStyle(
                    fontSize: 20,
                    fontWeight: FontWeight.bold,
                    color: Colors.green.shade400,
                  ),
                ),
              ],
            ),
            const SizedBox(height: 4),
          ],
        ),
      ),
    );
  }
}
