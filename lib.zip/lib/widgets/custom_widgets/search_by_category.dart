import 'package:flutter/material.dart';
import 'package:organicplants/services/all_plants_global_data.dart';
import 'package:organicplants/screens/BottomNavTab/store_tab.dart';
import 'package:organicplants/widgets/custom_widgets/plantcategory.dart';

class SearchByCategory extends StatelessWidget {
  const SearchByCategory({super.key});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 5),
      child: Column(
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(
                'Search by Category',
                style: TextStyle(
                  fontSize: 20,
                  fontWeight: FontWeight.bold,
                  color: Colors.green.shade400,
                ),
              ),
              GestureDetector(
                onTap: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(builder: (context) => StoreTab()),
                  );
                },
                child: Text(
                  'See All  ',
                  style: TextStyle(fontSize: 16, color: Colors.green.shade400),
                ),
              ),
            ],
          ),
          SizedBox(
            height: 120,
            child: ListView.builder(
              scrollDirection: Axis.horizontal,
              itemCount: categories.length,
              // padding: const EdgeInsets.symmetric(
              //   horizontal: 5,
              // ), // Adjusted padding for better spacing
              shrinkWrap: true, //
              itemBuilder: (context, index) {
                return Padding(
                  padding: const EdgeInsets.symmetric(
                    horizontal: 5,
                    vertical: 10,
                  ), //
                  child: GestureDetector(
                    onTap: () {
                      // Navigate to PlantCategory with the selected category
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder:
                              (context) => PlantCategory(
                                plant: getPlantsByCategory(
                                  categories[index]['filterTag']!
                                      .toLowerCase()
                                      .trim(),
                                ),
                                category: categories[index]['title']!,
                                
                                
                              ),
                        ),
                      );
                    },
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                      children: [
                        Container(
                          decoration: BoxDecoration(
                            shape: BoxShape.circle,
                            color: const Color.fromARGB(255, 237, 247, 237),
                          ),
                          padding: const EdgeInsets.all(5),
                          child: ClipOval(
                            child: Image.asset(
                              categories[index]['imagePath']!,
                              width: 70,
                              height: 70,
                              fit: BoxFit.cover,
                            ),
                          ),
                        ),
                        const SizedBox(height: 5),
                        Expanded(
                          child: Text(
                            categories[index]['title']!,
                            //textAlign: TextAlign.center,
                            style: TextStyle(
                              fontSize: 14,
                              color: Colors.green.shade400,
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                );
              },
            ),
          ),
        ],
      ),
    );
  }
}
